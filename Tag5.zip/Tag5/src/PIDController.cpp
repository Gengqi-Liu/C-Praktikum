#include "PIDController.h"


PIDController::PIDController(double Kp,
                             double Ki,
                             double Kd,
                             double Ta)
{
    m_dKp = Kp;
    m_dKi = Ki;
    m_dKd = Kd;
    m_dTa = Ta;

    m_dEsum = 0.0;
    m_deold = 0.0;
    m_dU = 0.0;
}


void PIDController::calculateU(double w, double y)
{
    double e;

    e = w - y;

    m_dEsum = m_dEsum + e;

    m_dU =
        m_dKp * e
        + m_dKi * m_dTa * m_dEsum
        + m_dKd * (e - m_deold) / m_dTa;

    m_deold = e;
}


double PIDController::GetU()
{
    return m_dU;
}
