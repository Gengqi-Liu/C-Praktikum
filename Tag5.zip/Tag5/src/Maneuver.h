#ifndef MANEUVER_H
#define MANEUVER_H


#include <list>
#include <string>


class Maneuver
{
private:

    // Ein Punkt der Koordinatenliste
    struct Coord
    {
        double dX;
        double dY;
        double dSpeed;

        Coord(double x, double y, double speed)
        {
            dX = x;
            dY = y;
            dSpeed = speed;
        }
    };


    // Koordinatenliste
    std::list<Coord> m_CoordList;


    // Iterator auf aktuellen Sollpunkt
    std::list<Coord>::iterator m_iter;


    // L�uft momentan ein Man�ver?
    bool m_bIsRunning;


    // Wunschgeschwindigkeit
    // [0] = rechts
    // [1] = links
    double m_adWishSpeed[2];


    // Maximale Geschwindigkeit
    double m_dMaxSpeed;


    // Erlaubte Positionsabweichung
    double m_dPosDifference;


public:

    Maneuver();


    // Koordinatenlisten erzeugen
    void CalcCircle(double dRadius,
                    double dSpeed,
                    double dTimestep);

    void CalcEight(double dRadius,
                   double dSpeed,
                   double dTimestep);


    // Liste in Datei schreiben
    void LogList(std::string sDatei);


    // Kontrollmethoden
    bool isRunning();

    void Start();

    void Stop();

    void Proceed();


    // Wunschgeschwindigkeiten berechnen
    void CalcManeuverSpeed(double dX,
                           double dY,
                           double dW);


    // Wunschgeschwindigkeiten zur�ckgeben
    double* GetManeuverSpeed();
};


#endif
