#include "RobotControl.h"

#include <iostream>
#include <ncurses.h>
#include <signal.h>


// Statischen Pointer definieren
RobotControl* RobotControl::transferPointer;



// ==================================================
// Konstruktor
// ==================================================

RobotControl::RobotControl()
    : m_MotorR(500.0, 100.0, 0.0, 0.04),
      m_MotorL(500.0, 100.0, 0.0, 0.04)
{
    // Anfangsgeschwindigkeit
    m_dActualSpeed[0] = 0.0;
    m_dActualSpeed[1] = 0.0;


    // Motoren stehen
    m_iMicros[0] = 1500;
    m_iMicros[1] = 1500;


    // Programm ist zunächst aktiv
    m_bIsActive = true;


    // Interface initialisieren
    m_Interface.Initialize(
        0.04,
        transferFunction
    );


    // Pointer auf dieses Objekt setzen
    transferPointer = this;
}



// ==================================================
// transferFunction
// ==================================================

void RobotControl::transferFunction()
{
    transferPointer->Step();
}



// ==================================================
// isActive
// ==================================================

bool RobotControl::isActive()
{
    return m_bIsActive;
}



// ==================================================
// Communicate
// ==================================================

void RobotControl::Communicate()
{
    // ==============================================
    // Zuerst normale Kommunikation mit iostream
    // ==============================================

    char cAntwort;


    std::cout
        << "Soll ein neues Manoever gefahren werden? (j/n): ";

    std::cin >> cAntwort;


    // Benutzer möchte kein weiteres Manöver
    if (cAntwort != 'j')
    {
        m_bIsActive = false;

        return;
    }



    // ==============================================
    // Radius und Geschwindigkeit einlesen
    // ==============================================

    double dRadius;
    double dSpeed;

    int iManeuver;


    std::cout << "Radius [m]: ";
    std::cin >> dRadius;


    std::cout << "Geschwindigkeit [m/s]: ";
    std::cin >> dSpeed;


    std::cout
        << "Manoever waehlen:\n"
        << "1 = Kreis\n"
        << "2 = Acht\n";

    std::cin >> iManeuver;



    // ==============================================
    // Koordinatenliste erzeugen
    //
    // timestep = 0.04 s
    // ==============================================

    if (iManeuver == 1)
    {
        m_Maneuver.CalcCircle(
            dRadius,
            dSpeed,
            0.04
        );
    }
    else
    {
        m_Maneuver.CalcEight(
            dRadius,
            dSpeed,
            0.04
        );
    }



    // ==============================================
    // Positionsschätzung zurücksetzen
    // ==============================================

    m_PosEstimation.Reset();



    // ==============================================
    // ncurses starten
    // ==============================================

    initscr();

    nodelay(stdscr, TRUE);

    noecho();



    // ==============================================
    // Step-Methode starten
    // ==============================================

    sigprocmask(
        SIG_UNBLOCK,
        &m_Interface.mask,
        nullptr
    );



    int iTaste = -1;

    bool bQuit = false;



    clear();

    printw("s = Start\n");
    printw("b = Stop\n");
    printw("p = Proceed\n");
    printw("q = Quit\n");



    // ==============================================
    // Benutzersteuerung
    // ==============================================

    while (!bQuit)
    {
        iTaste = getch();


        if (iTaste != -1)
        {
            // Manöver von vorne starten
            if (iTaste == 's')
            {
                m_Maneuver.Start();

                clear();
                printw("Manoever gestartet\n");
            }


            // Manöver stoppen / pausieren
            else if (iTaste == 'b')
            {
                m_Maneuver.Stop();

                clear();
                printw("Manoever gestoppt\n");
            }


            // Unterbrochenes Manöver fortsetzen
            else if (iTaste == 'p')
            {
                m_Maneuver.Proceed();

                clear();
                printw("Manoever fortgesetzt\n");
            }


            // Programm verlassen
            else if (iTaste == 'q')
            {
                m_Maneuver.Stop();

                bQuit = true;
            }
        }
    }



    // ==============================================
    // Warten bis Roboter wirklich steht
    // ==============================================

    while (m_dActualSpeed[0] != 0.0 ||
           m_dActualSpeed[1] != 0.0)
    {
        // Step() läuft weiterhin
    }



    // ==============================================
    // Step-Methode stoppen
    // ==============================================

    sigprocmask(
        SIG_BLOCK,
        &m_Interface.mask,
        nullptr
    );



    // ncurses beenden
    endwin();
}



// ==================================================
// Step
// ==================================================

void RobotControl::Step()
{
    // ==============================================
    // 1. Istgeschwindigkeiten einlesen
    // ==============================================

    double* pdInput =
        m_Interface.GetInput();


    m_dActualSpeed[0] = pdInput[0];
    m_dActualSpeed[1] = pdInput[1];



    // ==============================================
    // Läuft ein Manöver?
    // ==============================================

    if (m_Maneuver.isRunning())
    {
        // ==========================================
        // 2. Positionsschätzung
        // ==========================================

        m_PosEstimation.PredictPosition(
            m_dActualSpeed[0],
            m_dActualSpeed[1],
            0.04
        );


        double* pdPosition =
            m_PosEstimation.GetPosition();



        // ==========================================
        // 3. Neue Wunschgeschwindigkeiten berechnen
        // ==========================================

        m_Maneuver.CalcManeuverSpeed(
            pdPosition[0],
            pdPosition[1],
            pdPosition[2]
        );


        double* pdWishSpeed =
            m_Maneuver.GetManeuverSpeed();



        // ==========================================
        // Falls CalcManeuverSpeed das Ende
        // des Manövers erreicht hat
        // ==========================================

        if (!m_Maneuver.isRunning())
        {
            m_iMicros[0] = 1500;
            m_iMicros[1] = 1500;
        }
        else
        {
            // ======================================
            // 4. PID-Regler
            // ======================================

            m_MotorR.calculateU(
                pdWishSpeed[0],
                m_dActualSpeed[0]
            );


            m_MotorL.calculateU(
                pdWishSpeed[1],
                m_dActualSpeed[1]
            );



            // ======================================
            // 5. Stellgröße in Signallänge umwandeln
            // ======================================

            m_iMicros[0] =
                1500 + m_MotorR.GetU();


            m_iMicros[1] =
                1500 + m_MotorL.GetU();



            // ======================================
            // 6. Bereich [1000,2000] sicherstellen
            // ======================================

            if (m_iMicros[0] > 2000)
                m_iMicros[0] = 2000;

            if (m_iMicros[0] < 1000)
                m_iMicros[0] = 1000;


            if (m_iMicros[1] > 2000)
                m_iMicros[1] = 2000;

            if (m_iMicros[1] < 1000)
                m_iMicros[1] = 1000;
        }
    }

    else
    {
        // ==========================================
        // Kein Manöver aktiv
        // → Roboter stoppen
        // ==========================================

        m_iMicros[0] = 1500;
        m_iMicros[1] = 1500;
    }



    // ==============================================
    // 7. Signallängen an Simulation senden
    // ==============================================

    m_Interface.SetOutputs(m_iMicros);
}
