#include "RobotControl.h"


int main()
{
    RobotControl control;


    do
    {
        control.Communicate();
    }
    while (control.isActive());


    return 0;
}
