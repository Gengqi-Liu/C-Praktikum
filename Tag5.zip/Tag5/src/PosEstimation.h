#ifndef POSESTIMATION_H
#define POSESTIMATION_H


class PosEstimation
{
private:

    // x[0] = x-Koordinate
    // x[1] = y-Koordinate
    // x[2] = Raumrichtung
    double m_dX[3];

    // Mittlere Geschwindigkeit des vorherigen Zeitschritts
    double m_dVelAverage;


public:

    PosEstimation();

    // Alles auf Null zur�cksetzen
    void Reset();

    // Neue Position berechnen
    void PredictPosition(double dSpeedR,
                         double dSpeedL,
                         double dTimestep);

    // Adresse des Positionsarrays zur�ckgeben
    double* GetPosition();
};

#endif

