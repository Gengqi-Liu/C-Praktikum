
#ifndef PIDCONTROLLER_H
#define PIDCONTROLLER_H


class PIDController
{
private:

    double m_dKp;
    double m_dKi;
    double m_dKd;
    double m_dTa;

    double m_dEsum;
    double m_deold;
    double m_dU;


public:

    PIDController(double Kp,
                  double Ki,
                  double Kd,
                  double Ta);

    void calculateU(double w, double y);

    double GetU();
};


#endif

