#ifndef ROBOTCONTROL_H
#define ROBOTCONTROL_H


#include "InterfaceSIM.h"
#include "Maneuver.h"
#include "PosEstimation.h"
#include "PIDController.h"


class RobotControl
{
private:

    // Schnittstelle zur Simulation
    InterfaceSIM m_Interface;


    // Man�ver
    Maneuver m_Maneuver;


    // Positionssch�tzung
    PosEstimation m_PosEstimation;


    // Ein PID-Regler pro Motor
    PIDController m_MotorR;
    PIDController m_MotorL;


    // Aktuelle Istgeschwindigkeiten
    double m_dActualSpeed[2];


    // Signall�ngen
    int m_iMicros[2];


    // Programm aktiv?
    bool m_bIsActive;


public:

    RobotControl();


    // Parallelisierung
    static RobotControl* transferPointer;

    static void transferFunction();


    // Status des Programms
    bool isActive();


    // Zyklische Robotersteuerung
    void Step();


    // Kommunikation mit Benutzer
    void Communicate();
};


#endif
