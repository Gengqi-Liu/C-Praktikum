#include "Maneuver.h"

#include <cmath>
#include <fstream>


Maneuver::Maneuver()
{
    m_bIsRunning = false;

    m_adWishSpeed[0] = 0.0;
    m_adWishSpeed[1] = 0.0;

    // Maximale Geschwindigkeit laut Skript
    m_dMaxSpeed = 0.5;

    // 2 cm Positionsabweichung
    m_dPosDifference = 0.02;
}



// ==================================================
// Kreis erzeugen
// ==================================================

void Maneuver::CalcCircle(double dRadius,
                          double dSpeed,
                          double dTimestep)
{
    // Alte Liste l�schen
    m_CoordList.clear();


    // Vorgegebene for-Schleife aus dem Skript
    for (int counter = 1;
         counter <
         (int)((2.0 * M_PI)
         / ((dSpeed / dRadius) * dTimestep));
         counter++)
    {
        double dX =
            dRadius
            * sin(counter
            * (dSpeed / dRadius)
            * dTimestep);


        double dY =
            dRadius
            * (1.0
            - cos(counter
            * (dSpeed / dRadius)
            * dTimestep));


        // Punkt in Liste speichern
        m_CoordList.push_back(
            Coord(dX, dY, dSpeed)
        );
    }
}



// ==================================================
// Acht erzeugen
// ==================================================

void Maneuver::CalcEight(double dRadius,
                         double dSpeed,
                         double dTimestep)
{
    // Alte Liste l�schen
    m_CoordList.clear();


    // ----------------------------------------------
    // Erster Teilkreis
    // ----------------------------------------------

    for (int counter = 1;
         counter <
         (int)((2.0 * M_PI)
         / ((dSpeed / dRadius) * dTimestep));
         counter++)
    {
        double dX =
            dRadius
            * sin(counter
            * (dSpeed / dRadius)
            * dTimestep);


        double dY =
            dRadius
            * (1.0
            - cos(counter
            * (dSpeed / dRadius)
            * dTimestep));


        m_CoordList.push_back(
            Coord(dX, dY, dSpeed)
        );
    }


    // ----------------------------------------------
    // Zweiter Teilkreis
    // ----------------------------------------------

    for (int counter = 1;
         counter <
         (int)((2.0 * M_PI)
         / ((dSpeed / dRadius) * dTimestep));
         counter++)
    {
        double dX =
            dRadius
            * sin(counter
            * (dSpeed / dRadius)
            * dTimestep);


        double dY =
            (-dRadius)
            * (1.0
            - cos(counter
            * (dSpeed / dRadius)
            * dTimestep));


        m_CoordList.push_back(
            Coord(dX, dY, dSpeed)
        );
    }
}



// ==================================================
// Koordinatenliste speichern
// ==================================================

void Maneuver::LogList(std::string sDatei)
{
    std::ofstream datei(sDatei);


    for (std::list<Coord>::iterator iter =
             m_CoordList.begin();
         iter != m_CoordList.end();
         iter++)
    {
        datei
            << iter->dX << "\t"
            << iter->dY << std::endl;
    }


    datei.close();
}



// ==================================================
// Kontrollmethoden
// ==================================================

bool Maneuver::isRunning()
{
    return m_bIsRunning;
}


void Maneuver::Start()
{
    // Wieder am Anfang beginnen
    m_iter = m_CoordList.begin();

    m_bIsRunning = true;
}


void Maneuver::Stop()
{
    m_bIsRunning = false;

    m_adWishSpeed[0] = 0.0;
    m_adWishSpeed[1] = 0.0;
}


void Maneuver::Proceed()
{
    // Iterator NICHT zur�cksetzen
    m_bIsRunning = true;
}



// ==================================================
// Geschwindigkeit f�r das Man�ver berechnen
// ==================================================

void Maneuver::CalcManeuverSpeed(double dX,
                                 double dY,
                                 double dW)
{
    // Sicherheit: leere Liste
    if (m_CoordList.empty())
    {
        Stop();
        return;
    }


    // Sicherheit: Ende bereits erreicht
    if (m_iter == m_CoordList.end())
    {
        Stop();
        return;
    }


    // ==============================================
    // 1. Positionsvergleich
    // ==============================================

    double dDeltaX = m_iter->dX - dX;
    double dDeltaY = m_iter->dY - dY;


    double dDistance =
        sqrt(dDeltaX * dDeltaX
           + dDeltaY * dDeltaY);


    // Sollpunkt mit ausreichender Genauigkeit erreicht
    if (dDistance <= m_dPosDifference)
    {
        m_iter++;
    }



    // ==============================================
    // 2. Ende der Liste �berpr�fen
    // ==============================================

    if (m_iter == m_CoordList.end())
    {
        m_adWishSpeed[0] = 0.0;
        m_adWishSpeed[1] = 0.0;

        Stop();

        return;
    }



    // ==============================================
    // 3. Winkel zwischen Soll- und Istposition
    // ==============================================

    double dPhi =
        atan2(
            m_iter->dY - dY,
            m_iter->dX - dX
        );



    // ==============================================
    // 4. Winkeldifferenz
    // ==============================================

    double dDeltaPhi = dPhi - dW;



    // ==============================================
    // 5. Winkeldifferenz auf ]-pi, pi] begrenzen
    // ==============================================

    if (dDeltaPhi <= -M_PI)
    {
        dDeltaPhi += 2.0 * M_PI;
    }

    if (dDeltaPhi > M_PI)
    {
        dDeltaPhi -= 2.0 * M_PI;
    }



    // ==============================================
    // 6. Rotationsanteil
    //
    // Faktor = 2 m/(s rad)
    // ==============================================

    double dRot = 2.0 * dDeltaPhi;


    // Auf [-0.5, 0.5] begrenzen
    if (dRot > m_dMaxSpeed)
    {
        dRot = m_dMaxSpeed;
    }

    if (dRot < -m_dMaxSpeed)
    {
        dRot = -m_dMaxSpeed;
    }



    // ==============================================
    // 7. Translationsanteil
    // ==============================================

    double dTra = m_iter->dSpeed;



    // ==============================================
    // 8. Geschwindigkeitsanteile �berpr�fen
    //
    // Rotationsanteil muss erhalten bleiben.
    // Falls notwendig wird Translation reduziert.
    // ==============================================

    if (dTra * dRot > 0.0)
    {
        if (dTra + dRot > m_dMaxSpeed)
        {
            dTra = m_dMaxSpeed - dRot;
        }

        if (dTra + dRot < -m_dMaxSpeed)
        {
            dTra = -m_dMaxSpeed - dRot;
        }
    }
    else
    {
        if (dTra - dRot > m_dMaxSpeed)
        {
            dTra = m_dMaxSpeed + dRot;
        }

        if (dTra - dRot < -m_dMaxSpeed)
        {
            dTra = -m_dMaxSpeed + dRot;
        }
    }



    // ==============================================
    // 9. Geschwindigkeiten summieren
    // ==============================================

    // rechts
    m_adWishSpeed[0] = dTra + dRot;

    // links
    m_adWishSpeed[1] = dTra - dRot;



    // Zus�tzliche Begrenzung auf Maximalbetrag 0.5
    if (m_adWishSpeed[0] > m_dMaxSpeed)
        m_adWishSpeed[0] = m_dMaxSpeed;

    if (m_adWishSpeed[0] < -m_dMaxSpeed)
        m_adWishSpeed[0] = -m_dMaxSpeed;

    if (m_adWishSpeed[1] > m_dMaxSpeed)
        m_adWishSpeed[1] = m_dMaxSpeed;

    if (m_adWishSpeed[1] < -m_dMaxSpeed)
        m_adWishSpeed[1] = -m_dMaxSpeed;
}



double* Maneuver::GetManeuverSpeed()
{
    return m_adWishSpeed;
}

