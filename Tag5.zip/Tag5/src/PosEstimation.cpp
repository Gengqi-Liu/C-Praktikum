#include "PosEstimation.h"
#include <cmath>


PosEstimation::PosEstimation()
{
    Reset();
}


void PosEstimation::Reset()
{
    m_dX[0] = 0.0;
    m_dX[1] = 0.0;
    m_dX[2] = 0.0;

    m_dVelAverage = 0.0;
}


void PosEstimation::PredictPosition(double dSpeedR,
                                    double dSpeedL,
                                    double dTimestep)
{
    // 1. x-Koordinate berechnen
    // Wichtig: alte mittlere Geschwindigkeit
    // und alten Winkel verwenden
    m_dX[0] =
        m_dX[0]
        + m_dVelAverage
        * dTimestep
        * cos(m_dX[2]);


    // 2. y-Koordinate berechnen
    m_dX[1] =
        m_dX[1]
        + m_dVelAverage
        * dTimestep
        * sin(m_dX[2]);


    // 3. Raumrichtung berechnen
    // Spurbreite B = 0.23 m
    m_dX[2] =
        m_dX[2]
        + dTimestep
        * ((dSpeedR - dSpeedL) / 0.23);


    // 4. Winkel zun�chst auf ]-2*pi, 2*pi[ begrenzen
    m_dX[2] = fmod(m_dX[2], 2.0 * M_PI);


    // 5. Winkel auf ]-pi, pi] begrenzen
    if (m_dX[2] > M_PI)
    {
        m_dX[2] -= 2.0 * M_PI;
    }

    if (m_dX[2] <= -M_PI)
    {
        m_dX[2] += 2.0 * M_PI;
    }


    // 6. Neue mittlere Geschwindigkeit berechnen
    // Diese wird im n�chsten Zeitschritt verwendet
    m_dVelAverage =
        (dSpeedR + dSpeedL) / 2.0;
}


double* PosEstimation::GetPosition()
{
    return m_dX;
}
