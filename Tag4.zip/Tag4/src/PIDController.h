#ifndef PIDCONTROLLER_H
#define PIDCONTROLLER_H


class PIDController
{
private:

    // Verst�rkungsfaktoren
    double m_dKp;
    double m_dKi;
    double m_dKd;

    // Abtastzeit
    double m_dTa;

    // Summe der Regelabweichungen
    double m_dEsum;

    // Regelabweichung des vorherigen Zeitschritts
    double m_deold;

    // Stellgr��e
    double m_dU;


public:

    // Konstruktor
    PIDController(double Kp,
                  double Ki,
                  double Kd,
                  double Ta);

    // Berechnung der Stellgr��e
    void calculateU(double w, double y);

    // Stellgr��e zur�ckgeben
    double GetU();
};


#endif
