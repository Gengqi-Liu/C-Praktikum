#include "KeyboardControl.h"

int main()
{
    // Objekt der Klasse KeyboardControl erstellen
    KeyboardControl control;

    // Tastatursteuerung starten
    control.Communicate();

    return 0;
}
