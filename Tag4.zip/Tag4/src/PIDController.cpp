#include "PIDController.h"


PIDController::PIDController(double Kp,
                             double Ki,
                             double Kd,
                             double Ta)
{
    // Reglerparameter speichern
    m_dKp = Kp;
    m_dKi = Ki;
    m_dKd = Kd;
    m_dTa = Ta;

    // Anfangswerte
    m_dEsum = 0.0;
    m_deold = 0.0;
    m_dU = 0.0;
}


void PIDController::calculateU(double w, double y)
{
    // Regelabweichung
    double e;

    // e(k) = Sollwert - Istwert
    e = w - y;

    // E(k) = E(k-1) + e(k)
    m_dEsum = m_dEsum + e;

    // PID-Regelalgorithmus
    m_dU =
        m_dKp * e
        + m_dKi * m_dTa * m_dEsum
        + m_dKd * (e - m_deold) / m_dTa;

    // Fehler f�r n�chsten Zeitschritt speichern
    m_deold = e;
}


double PIDController::GetU()
{
    return m_dU;
}


