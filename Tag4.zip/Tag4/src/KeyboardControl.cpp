#include "KeyboardControl.h"

#include <iostream>
#include <ncurses.h>
#include <signal.h>


// Statischen Pointer definieren
KeyboardControl* KeyboardControl::transferPointer;


// Konstruktor
//
// Die beiden PID-Regler werden laut Skript
// �ber die Initialisierungsliste initialisiert.
//
// Kp = 500.0
// Ki = 1850.0
// Kd = 0.0
// Ta = 0.04
KeyboardControl::KeyboardControl()
    : m_ReglerRechts(500.0, 1850.0, 0.0, 0.04),
      m_ReglerLinks(500.0, 1850.0, 0.0, 0.04)
{
    // Anfangswert der Sollgeschwindigkeit
    m_dSollGeschwindigkeit[0] = 0.0;
    m_dSollGeschwindigkeit[1] = 0.0;


    // Anfangswert der Istgeschwindigkeit
    m_dIstGeschwindigkeit[0] = 0.0;
    m_dIstGeschwindigkeit[1] = 0.0;


    // Nulllage des Servosignals
    m_iMicros[0] = 1500;
    m_iMicros[1] = 1500;


    // Pointer zeigt auf das aktuelle Objekt
    transferPointer = this;


    // InterfaceSIM initialisieren
    //
    // Zeitschrittl�nge = 0.04 s
    // transferFunction wird zyklisch aufgerufen
    m_Interface.Initialize(0.04, transferFunction);
}



// --------------------------------------------------
// transferFunction
// --------------------------------------------------

void KeyboardControl::transferFunction()
{
    // Step() �ber transferPointer aufrufen
    transferPointer->Step();
}



// --------------------------------------------------
// Communicate
// --------------------------------------------------

void KeyboardControl::Communicate()
{
    // ncurses starten
    initscr();

    // getch() soll nicht auf eine Eingabe warten
    nodelay(stdscr, TRUE);

    // Tasteneingaben nicht zus�tzlich anzeigen
    noecho();


    int iTaste = -1;

    bool bQuit = false;


    // ----------------------------------------------
    // Parallele Ausf�hrung von Step() starten
    // ----------------------------------------------

    sigprocmask(SIG_UNBLOCK,
                &m_Interface.mask,
                nullptr);



    // ==============================================
    // Erste Schleife:
    // Kommunikation mit dem Benutzer
    // ==============================================

    while (!bQuit)
    {
        // Taste einlesen
        iTaste = getch();


        // Nur reagieren, wenn wirklich
        // eine Taste gedr�ckt wurde
        if (iTaste != -1)
        {

            // --------------------------------------
            // w = vorw�rts
            // --------------------------------------

            if (iTaste == 'w')
            {
                m_dSollGeschwindigkeit[0] += 0.01;
                m_dSollGeschwindigkeit[1] += 0.01;
            }


            // --------------------------------------
            // s = r�ckw�rts
            // --------------------------------------

            else if (iTaste == 's')
            {
                m_dSollGeschwindigkeit[0] -= 0.01;
                m_dSollGeschwindigkeit[1] -= 0.01;
            }


            // --------------------------------------
            // a = links
            //
            // rechter Motor +0.005
            // linker Motor  -0.005
            // --------------------------------------

            else if (iTaste == 'a')
            {
                m_dSollGeschwindigkeit[0] += 0.005;
                m_dSollGeschwindigkeit[1] -= 0.005;
            }


            // --------------------------------------
            // d = rechts
            //
            // rechter Motor -0.005
            // linker Motor  +0.005
            // --------------------------------------

            else if (iTaste == 'd')
            {
                m_dSollGeschwindigkeit[0] -= 0.005;
                m_dSollGeschwindigkeit[1] += 0.005;
            }


            // --------------------------------------
            // b = break
            //
            // Roboter anhalten,
            // Programm aber nicht beenden
            // --------------------------------------

            else if (iTaste == 'b')
            {
                m_dSollGeschwindigkeit[0] = 0.0;
                m_dSollGeschwindigkeit[1] = 0.0;
            }


            // --------------------------------------
            // q = quit
            //
            // Roboter anhalten und
            // erste Schleife verlassen
            // --------------------------------------

            else if (iTaste == 'q')
            {
                m_dSollGeschwindigkeit[0] = 0.0;
                m_dSollGeschwindigkeit[1] = 0.0;

                bQuit = true;
            }



            // ======================================
            // Sollgeschwindigkeiten begrenzen
            //
            // Erlaubter Bereich:
            // [-0.5, +0.5] m/s
            // ======================================


            // rechter Motor

            if (m_dSollGeschwindigkeit[0] > 0.5)
            {
                m_dSollGeschwindigkeit[0] = 0.5;
            }

            if (m_dSollGeschwindigkeit[0] < -0.5)
            {
                m_dSollGeschwindigkeit[0] = -0.5;
            }


            // linker Motor

            if (m_dSollGeschwindigkeit[1] > 0.5)
            {
                m_dSollGeschwindigkeit[1] = 0.5;
            }

            if (m_dSollGeschwindigkeit[1] < -0.5)
            {
                m_dSollGeschwindigkeit[1] = -0.5;
            }



            // ======================================
            // Werte in der Konsole anzeigen
            // ======================================

            clear();


            printw(
                "Letzte Taste: %c\n",
                iTaste
            );


            printw(
                "Sollgeschwindigkeit rechts: %.3f m/s\n",
                m_dSollGeschwindigkeit[0]
            );


            printw(
                "Sollgeschwindigkeit links:  %.3f m/s\n",
                m_dSollGeschwindigkeit[1]
            );
        }
    }



    // ==============================================
    // Zweite Schleife
    //
    // Nach q warten, bis der Roboter
    // tats�chlich steht.
    //
    // Step() l�uft w�hrenddessen weiter.
    // ==============================================

    while (m_dIstGeschwindigkeit[0] != 0.0 ||
           m_dIstGeschwindigkeit[1] != 0.0)
    {
        // Warten bis Istgeschwindigkeiten = 0
    }



    // ==============================================
    // Parallele Ausf�hrung von Step() beenden
    // ==============================================

    sigprocmask(SIG_BLOCK,
                &m_Interface.mask,
                nullptr);



    // ncurses ausschalten
    endwin();
}



// --------------------------------------------------
// Step
// --------------------------------------------------

void KeyboardControl::Step()
{
    // ==============================================
    // 1. Istgeschwindigkeit einlesen
    //
    // GetInput() darf laut Skript nur EINMAL
    // am Anfang von Step() aufgerufen werden.
    // ==============================================

    double* pdInput = m_Interface.GetInput();


    // rechte Istgeschwindigkeit
    m_dIstGeschwindigkeit[0] = pdInput[0];


    // linke Istgeschwindigkeit
    m_dIstGeschwindigkeit[1] = pdInput[1];



    // ==============================================
    // 2. PID-Regler rechter Motor
    //
    // Sollgeschwindigkeit = F�hrungsgr��e
    // Istgeschwindigkeit  = Regelgr��e
    // ==============================================

    m_ReglerRechts.calculateU(
        m_dSollGeschwindigkeit[0],
        m_dIstGeschwindigkeit[0]
    );



    // ==============================================
    // 3. PID-Regler linker Motor
    // ==============================================

    m_ReglerLinks.calculateU(
        m_dSollGeschwindigkeit[1],
        m_dIstGeschwindigkeit[1]
    );



    // ==============================================
    // 4. Stellgr��e holen und um 1500 �s verschieben
    //
    // Laut Skript:
    // Servosignal = 1500 �s + u
    // ==============================================

    m_iMicros[0] =
        1500 + m_ReglerRechts.GetU();


    m_iMicros[1] =
        1500 + m_ReglerLinks.GetU();



    // ==============================================
    // 5. Signall�ngen begrenzen
    //
    // Erlaubter Bereich:
    // [1000 �s, 2000 �s]
    // ==============================================


    // rechter Motor

    if (m_iMicros[0] > 2000)
    {
        m_iMicros[0] = 2000;
    }

    if (m_iMicros[0] < 1000)
    {
        m_iMicros[0] = 1000;
    }


    // linker Motor

    if (m_iMicros[1] > 2000)
    {
        m_iMicros[1] = 2000;
    }

    if (m_iMicros[1] < 1000)
    {
        m_iMicros[1] = 1000;
    }



    // ==============================================
    // 6. Stellgr��en an Simulation senden
    // ==============================================

    m_Interface.SetOutputs(m_iMicros);
}
