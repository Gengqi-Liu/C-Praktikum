#ifndef KEYBOARDCONTROL_H
#define KEYBOARDCONTROL_H


#include "InterfaceSIM.h"
#include "PIDController.h"


class KeyboardControl
{
private:

    // Sollgeschwindigkeit
    // [0] = rechter Motor
    // [1] = linker Motor
    double m_dSollGeschwindigkeit[2];


    // Istgeschwindigkeit
    // [0] = rechter Motor
    // [1] = linker Motor
    double m_dIstGeschwindigkeit[2];


    // Signall�ngen
    // [0] = rechter Motor
    // [1] = linker Motor
    int m_iMicros[2];


    // Schnittstelle zur Simulation
    InterfaceSIM m_Interface;


    // PID-Regler
    // Ein Regler f�r jeden Motor
    PIDController m_ReglerRechts;
    PIDController m_ReglerLinks;


public:

    // Konstruktor
    KeyboardControl();


    // Kommunikation mit Tastatur
    void Communicate();


    // Kommunikation mit Simulation
    void Step();


    // Pointer f�r Parallelisierung
    static KeyboardControl* transferPointer;


    // Transferfunktion f�r Parallelisierung
    static void transferFunction();
};


#endif
